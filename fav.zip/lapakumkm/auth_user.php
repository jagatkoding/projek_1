<?php

if (isset($_SESSION['auth_admin'])) {
    header("Location: admin/index.php");
    exit();
}
