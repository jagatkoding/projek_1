<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "lapakumkm";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    echo "gagal konek database menn";
} else {
    //echo "Berhasil";
};
