<!DOCTYPE html>
<html lang="en">

<?php
include "../koneksi.php";
include "control.php";
include "auth.php";

?>

<head>
    <title>Admin</title>
</head>
<?php
include 'template/head.php';
?>

<body>
    <script>
        $(document).ready(function() {
            $('#dt').DataTable();
        });
    </script>

    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php
            include 'template/sidebar.php';
            ?>
            <div class="col py-3">
                <div class="container">
                    <h3>Dashboard</h3>
                    <br>
                    <br>
                    <button id="modal" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#add" data-id="" data-nama_umkm="" data-alamat="" data-telepon="" data-status="add">
                        <i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data
                    </button>
                    <p></p>
                    <div class="row">
                        <div class="col">
                            <div class="table-responsive">
                                <table class="table table-hover cell-border" id="dt">
                                    <thead>
                                        <tr>
                                            <th style="width: 5%;">No.</th>
                                            <th style="width: 85%;">Gambar</th>
                                            <th style="width: 10%;">#</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    $query = "SELECT * FROM tb_slider ORDER BY id_slider DESC";
                                    $sql = mysqli_query($conn, $query);
                                    $no = 1;
                                    ?>
                                    <tbody>
                                        <?php
                                        while ($result = mysqli_fetch_assoc($sql)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <center><?php echo $no++; ?>.</center>
                                                </td>
                                                <td><img width="100%" src="../slider/<?php echo $result['foto_slider']; ?>" alt=""></td>
                                                <td>
                                                    <a onclick="return confirm('Apakah Anda Yakin Hapus Data ?');" href="index.php?hapus=<?php echo $result['id_slider']; ?>" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="container p-3">
                            <input type="hidden" name="id_slider" id="id_slider">
                            <div class="mb-3 mt-3 row">
                                <label class="col-sm-4 col-form-label">Gambar Slider</label>
                                <div class="col-sm-8">
                                    <input required type="file" name="foto" id="foto" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="proses" type="submit" class="btn btn-primary">
                                <i class="fa fa-save"></i>&nbsp; <span id="pros">Simpan</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['add'])) {
        $data = array(
            "gambar" => $_FILES['foto'],
        );
        add_slider($data);
    }
    if (isset($_GET['hapus'])) {
        $data = array(
            "id" => $_GET['hapus'],
        );
        dell_slider($data);
    }
    ?>
</body>

<script>
    $(document).on("click", "#modal", function() {

        var id = $(this).data('id');
        var nama_umkm = $(this).data('nama_umkm');
        var alamat_umkm = $(this).data('alamat');
        var telepon = $(this).data('telepon');

        var status = $(this).data('status');

        //alert(status);
        if (status == "add") {
            $(".modal-footer #proses").attr("name", "add");
            $(".modal-footer #pros").text("Tambahkan");
        } else if (status == "edit") {
            $(".modal-footer #proses").attr("name", "edit");
            $(".modal-footer #pros").text("Simpan Perubahan");
        }

        $(".modal-body #id_umkm").val(id);
        $(".modal-body #nama_umkm").val(nama_umkm);
        $(".modal-body #alamat_umkm").val(alamat_umkm);
        $(".modal-body #telepon").val(telepon);
        //alert(nama);
    });
</script>

</html>