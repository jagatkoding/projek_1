<?php
include "../koneksi.php";

function rupiah($angka)
{

    $hasil_rupiah = "Rp. " . number_format($angka, 0, ',', '.');
    return $hasil_rupiah;
}

function add_kategori($data)
{
    $kategori = $data['nama_kategori'];

    $query = "INSERT INTO tb_kategori VALUES('' , '$kategori');";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'kategori.php';
         }, 100);
        </script>";
    }
}

function dell_kategori($data)
{
    $id = $data['id'];
    $query = "DELETE FROM tb_kategori where id_kategori = '$id';";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'kategori.php';
         }, 100);
        </script>";
    }
}

function add_umkm($data)
{
    $nama = $data['nama'];
    $alamat = $data['alamat'];
    $telepon = $data['telepon'];

    $query = "INSERT INTO tb_umkm VALUES('' , '$nama', '$alamat', '$telepon');";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'data_umkm.php';
         }, 100);
        </script>";
    }
}

function edit_umkm($data)
{
    $id = $data['id'];
    $nama = $data['nama'];
    $alamat = $data['alamat'];
    $telepon = $data['telepon'];

    $query = "UPDATE tb_umkm SET nama_umkm='$nama', alamat_umkm='$alamat', telepon='$telepon' WHERE id_umkm = '$id';";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'data_umkm.php';
         }, 100);
        </script>";
    }
}

function dell_umkm($data)
{
    $id = $data['id'];
    $query = "DELETE FROM tb_umkm where id_umkm = '$id';";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'data_umkm.php';
         }, 100);
        </script>";
    }
}

function add_product($data)
{
    $nama = $data['nama_product'];
    $deskripsi = $data['deskripsi'];
    $harga = $data['harga'];
    $stok = $data['stok'];
    $kategori = $data['kategori'];
    $umkm = $data['umkm'];

    $query = "INSERT INTO tb_product VALUES('' , '$nama', '$deskripsi', '$harga', '$stok', '$kategori', '$umkm', '-');";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    $query2 = "SELECT * FROM tb_product ORDER BY id_product DESC LIMIT 1;";
    $sql2 = mysqli_query($GLOBALS['conn'], $query2);
    $result = mysqli_fetch_assoc($sql2);

    //var_dump($result);
    //die();

    $gambar = $data['gambar']['name'];
    $dir = "img/";
    $split = explode('.', $gambar);
    $ekstensi = end($split);
    $nama_file = $result['id_product'] . "." . $ekstensi;
    $kirim = move_uploaded_file($data['gambar']['tmp_name'], $dir . $nama_file);
    $id_product = $result['id_product'];

    $query3 = "UPDATE tb_product SET gambar_product = '$nama_file' WHERE id_product = '$id_product';";
    $sql3 = mysqli_query($GLOBALS['conn'], $query3);

    if ($sql3) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'produk.php';
         }, 100);
        </script>";
    }
}

function dell_product($data)
{
    $id = $data['id'];

    $query2 = "SELECT * FROM tb_product WHERE id_product = $id;";
    $sql2 = mysqli_query($GLOBALS['conn'], $query2);
    $result = mysqli_fetch_assoc($sql2);

    $nama_foto = $result['gambar_product'];
    $dir = "img/";

    unlink($dir . $nama_foto);

    $query = "DELETE FROM tb_product where id_product = '$id';";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'produk.php';
         }, 100);
        </script>";
    }
}

function edit_product($data)
{
    //var_dump($data);
    //die();
    $id = $data['id'];
    $nama = $data['nama_product'];
    $deskripsi = $data['deskripsi'];
    $harga = $data['harga'];
    $stok = $data['stok'];
    $kategori = $data['kategori'];
    $umkm = $data['umkm'];

    $query = "UPDATE tb_product SET nama_product='$nama', detil_product='$deskripsi', harga_product='$harga', stok_product='$stok', id_kategori='$kategori', id_umkm='$umkm'  WHERE id_product = '$id';";

    //echo $query;
    //die();
    $sql = mysqli_query($GLOBALS['conn'], $query);

    $query2 = "SELECT * FROM tb_product WHERE id_product = '$id';";
    $sql2 = mysqli_query($GLOBALS['conn'], $query2);
    $result = mysqli_fetch_assoc($sql2);

    $dir = "img/";

    if ($data['gambar']['name'] == "") {
        //echo "Kosong";
    } else {
        unlink($dir . $result['gambar_product']);
        $gambar = $data['gambar']['name'];

        $split = explode('.', $gambar);
        $ekstensi = end($split);
        $nama_file = $result['id_product'] . "." . $ekstensi;
        $kirim = move_uploaded_file($data['gambar']['tmp_name'], $dir . $nama_file);
        $id_product = $result['id_product'];

        $query3 = "UPDATE tb_product SET gambar_product = '$nama_file' WHERE id_product = '$id_product';";
        $sql3 = mysqli_query($GLOBALS['conn'], $query3);
    }

    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'produk.php';
         }, 1000);
        </script>";
    }
}

function add_slider($data)
{
    $query = "INSERT INTO tb_slider VALUES('' , '-');";
    $sql = mysqli_query($GLOBALS['conn'], $query);

    $query2 = "SELECT * FROM tb_slider ORDER BY id_slider DESC LIMIT 1;";
    $sql2 = mysqli_query($GLOBALS['conn'], $query2);
    $result = mysqli_fetch_assoc($sql2);

    $gambar = $data['gambar']['name'];
    $dir = "../slider/";
    $split = explode('.', $gambar);
    $ekstensi = end($split);
    $nama_file = $result['id_slider'] . "." . $ekstensi;
    $kirim = move_uploaded_file($data['gambar']['tmp_name'], $dir . $nama_file);
    $id_slider = $result['id_slider'];

    $query3 = "UPDATE tb_slider SET foto_slider = '$nama_file' WHERE id_slider = '$id_slider';";
    $sql3 = mysqli_query($GLOBALS['conn'], $query3);

    if ($sql3) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'index.php';
         }, 100);
        </script>";
    }
}

function dell_slider($data)
{
    $id = $data['id'];

    $query2 = "SELECT * FROM tb_slider WHERE id_slider = $id;";
    $sql2 = mysqli_query($GLOBALS['conn'], $query2);
    $result = mysqli_fetch_assoc($sql2);

    $nama_foto = $result['foto_slider'];
    $dir = "../slider/";

    unlink($dir . $nama_foto);

    $query = "DELETE FROM tb_slider where id_slider = '$id';";
    $sql = mysqli_query($GLOBALS['conn'], $query);
    if ($sql) {
        echo "<script>
        setInterval( () => {
            window.location.href = 'index.php';
         }, 100);
        </script>";
    }
}
