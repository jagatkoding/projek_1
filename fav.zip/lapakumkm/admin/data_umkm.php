<!DOCTYPE html>
<html lang="en">

<?php
include "../koneksi.php";
include "control.php";
include "auth.php";
?>

<head>
    <title>Admin</title>
</head>
<?php
include 'template/head.php';
?>

<body>
    <script>
        $(document).ready(function() {
            $('#dt').DataTable();
        });
    </script>

    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php
            include 'template/sidebar.php';
            ?>
            <div class="col py-3">
                <div class="container">
                    <h3>Data UMKM</h3>
                    <br>
                    <button id="modal" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#add" data-id="" data-nama_umkm="" data-alamat="" data-telepon="" data-status="add">
                        <i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data
                    </button>
                    <p></p>
                    <div class="row">
                        <div class="col">
                            <div class="table-responsive">
                                <table class="table table-hover cell-border" id="dt">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama UMKM</th>
                                            <th>Alamat</th>
                                            <th>Telepon</th>
                                            <th>#</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    $query = "SELECT * FROM tb_umkm";
                                    $sql = mysqli_query($conn, $query);
                                    $no = 1;
                                    ?>
                                    <tbody>
                                        <?php
                                        while ($result = mysqli_fetch_assoc($sql)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <center><?php echo $no++; ?>.</center>
                                                </td>
                                                <td><?php echo $result['nama_umkm']; ?></td>
                                                <td><?php echo $result['alamat_umkm']; ?></td>
                                                <td><?php echo $result['telepon']; ?></td>
                                                <td>
                                                    <a onclick="return confirm('Apakah Anda Yakin Hapus Data ?');" href="data_umkm.php?hapus=<?php echo $result['id_umkm']; ?>" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                    <a id="modal" href="#" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#add" data-id="<?php echo $result['id_umkm']; ?>" data-nama_umkm="<?php echo $result['nama_umkm']; ?>" data-alamat="<?php echo $result['alamat_umkm']; ?>" data-telepon="<?php echo $result['telepon']; ?>" data-status="edit">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="" method="POST">
                        <div class="container p-3">
                            <input type="hidden" name="id_umkm" id="id_umkm">
                            <div class="mb-3 mt-3 row">
                                <label for="inputPassword" class="col-sm-4 col-form-label">Nama UMKM</label>
                                <div class="col-sm-8">
                                    <input id="nama_umkm" required type="text" name="nama_umkm" class="form-control">
                                </div>
                            </div>
                            <div class="mb-3 mt-3 row">
                                <label for="inputPassword" class="col-sm-4 col-form-label">Alamat</label>
                                <div class="col-sm-8">
                                    <textarea id="alamat_umkm" required class="form-control" name="alamat" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                </div>
                            </div>
                            <div class="mb-3 mt-3 row">
                                <label for="inputPassword" class="col-sm-4 col-form-label">Telepon</label>
                                <div class="col-sm-8">
                                    <input id="telepon" required type="text" class="form-control" name="telepon" placeholder="Telepon">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button id="proses" type="submit" name="submit" class="btn btn-primary">
                                <i class="fa fa-save"></i>&nbsp; <span id="pros">Simpan</span>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['add'])) {
        $data = array(
            "nama" => $_POST['nama_umkm'],
            "alamat" => $_POST['alamat'],
            "telepon" => $_POST['telepon']
        );
        add_umkm($data);
    }
    if (isset($_POST['edit'])) {
        $data2 = array(
            "id" => $_POST['id_umkm'],
            "nama" => $_POST['nama_umkm'],
            "alamat" => $_POST['alamat'],
            "telepon" => $_POST['telepon']
        );
        edit_umkm($data2);
    }
    if (isset($_GET['hapus'])) {
        $data = array(
            "id" => $_GET['hapus'],
        );
        dell_umkm($data);
    }
    ?>
</body>

<script>
    $(document).on("click", "#modal", function() {

        var id = $(this).data('id');
        var nama_umkm = $(this).data('nama_umkm');
        var alamat_umkm = $(this).data('alamat');
        var telepon = $(this).data('telepon');

        var status = $(this).data('status');

        //alert(status);
        if (status == "add") {
            $(".modal-footer #proses").attr("name", "add");
            $(".modal-footer #pros").text("Tambahkan");
        } else if (status == "edit") {
            $(".modal-footer #proses").attr("name", "edit");
            $(".modal-footer #pros").text("Simpan Perubahan");
        }

        $(".modal-body #id_umkm").val(id);
        $(".modal-body #nama_umkm").val(nama_umkm);
        $(".modal-body #alamat_umkm").val(alamat_umkm);
        $(".modal-body #telepon").val(telepon);
        //alert(nama);
    });
</script>

</html>