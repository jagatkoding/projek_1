<!DOCTYPE html>
<html lang="en">

<?php
include "../koneksi.php";
include "control.php";
include "auth.php";
?>

<head>
    <title>Admin</title>
</head>
<?php
include 'template/head.php';
?>

<body>
    <script>
        $(document).ready(function() {
            $('#dt').DataTable();
        });
    </script>

    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php
            include 'template/sidebar.php';
            ?>
            <div class="col py-3">
                <div class="container">
                    <h3>Data Produk</h3>
                    <br>
                    <button id="modal" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#kelola" href="#" class="btn btn-success btn-sm" data-id_product="" data-nama="" data-deskripsi="" data-harga="" data-stok="" data-kategori="" data-umkm="" data-status="add">
                        <i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data
                    </button>
                    <p></p>
                    <div class="row">
                        <div class="col">
                            <div class="table-responsive">
                                <table class="table table-hover cell-border" id="dt">
                                    <thead>
                                        <tr>
                                            <th style="width: 5%;">No.</th>
                                            <th style="width: 10%;">Barang</th>
                                            <th style="width: 20%;">Deskripsi</th>
                                            <th style="width: 15%;">Harga</th>
                                            <th style="width: 5%;">Stok</th>
                                            <th style="width: 10%;">Kategori</th>
                                            <th style="width: 10%;">Produksi</th>
                                            <th style="width: 15%;">Gambar</th>
                                            <th style="width: 20%;">#</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    $query = "SELECT * FROM tb_product LEFT JOIN tb_kategori ON tb_product.id_kategori = tb_kategori.id_kategori LEFT JOIN tb_umkm ON tb_product.id_umkm = tb_umkm.id_umkm ORDER BY id_product DESC;";
                                    //echo $query;
                                    $sql = mysqli_query($conn, $query);
                                    $no = 1;
                                    $a = 1;
                                    ?>
                                    <tbody>
                                        <?php
                                        while ($result = mysqli_fetch_assoc($sql)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <center><?php echo $no++; ?>.</center>
                                                </td>
                                                <td><?php echo $result['nama_product']; ?></td>
                                                <td><?php echo $result['detil_product']; ?></td>
                                                <td><?php echo rupiah($result['harga_product']); ?></td>
                                                <td><?php echo $result['stok_product']; ?></td>
                                                <td><?php echo $result['nama_kategori']; ?></td>
                                                <td><?php echo $result['nama_umkm']; ?></td>
                                                <td>
                                                    <center>
                                                        <img src="img/<?php echo $result['gambar_product']; ?>" alt="" width="100px">
                                                    </center>
                                                </td>
                                                <td>
                                                    <a onclick="return confirm('Apakah Anda Yakin Hapus Data ?');" href="produk.php?hapus=<?php echo $result['id_product']; ?>" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                    <a id="modal" data-bs-toggle="modal" data-bs-target="#kelola" href="#" class="btn btn-success btn-sm" data-id_product="<?php echo $result['id_product']; ?>" data-nama="<?php echo $result['nama_product']; ?>" data-deskripsi="<?php echo $result['detil_product']; ?>" data-harga="<?php echo $result['harga_product']; ?>" data-stok="<?php echo $result['stok_product']; ?>" data-kategori="<?php echo $result['id_kategori']; ?>" data-umkm="<?php echo $result['id_umkm']; ?>" data-status="edit">
                                                        <i class="fa fa-pencil"></i>
                                                    </a>

                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="kelola" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Kelola Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="id_product" id="id_product">
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Nama Produk</label>
                            <div class="col-sm-8">
                                <input id="nama_product" required type="text" name="nama_product" class="form-control">
                            </div>
                        </div>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Deskripsi</label>
                            <div class="col-sm-8">
                                <textarea id="deskripsi" required class="form-control" name="deskripsi" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                            </div>
                        </div>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Harga</label>
                            <div class="col-sm-8">
                                <input id="harga" required type="text" class="form-control" name="harga" placeholder="Harga">
                            </div>
                        </div>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Stok</label>
                            <div class="col-sm-8">
                                <input id="stok" required type="number" class="form-control" name="stok" placeholder="Stok">
                            </div>
                        </div>
                        <?php
                        $query1 = "SELECT * FROM tb_kategori";
                        $sql1 = mysqli_query($conn, $query1);
                        $no = 1;
                        ?>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Kategori</label>
                            <div class="col-sm-8">
                                <select id="kategori" required name="kategori" class="form-control">
                                    <option value="">Pilih Kategori</option>
                                    <?php
                                    while ($result1 = mysqli_fetch_assoc($sql1)) {
                                    ?>
                                        <option value="<?php echo $result1['id_kategori']; ?>"><?php echo $result1['nama_kategori']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <?php
                        $query2 = "SELECT * FROM tb_umkm";
                        $sql2 = mysqli_query($conn, $query2);
                        $no = 1;
                        ?>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">UMKM</label>
                            <div class="col-sm-8">
                                <select id="umkm" required name="umkm" class="form-control">
                                    <option value="">Pilih UMKM</option>
                                    <?php
                                    while ($result2 = mysqli_fetch_assoc($sql2)) {
                                    ?>
                                        <option value="<?php echo $result2['id_umkm']; ?>"><?php echo $result2['nama_umkm']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 mt-3 row">
                            <label class="col-sm-4 col-form-label">Gambar Product</label>
                            <div class="col-sm-8">
                                <input type="file" name="foto" id="foto1" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button id="proses" type="submit" name="submit" class="btn btn-primary">
                            <i class="fa fa-save"></i>&nbsp; <span id="pros">Simpan</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['add'])) {
        $data = array(
            "nama_product" => $_POST['nama_product'],
            "deskripsi" => $_POST['deskripsi'],
            "harga" => $_POST['harga'],
            "stok" => $_POST['stok'],
            "kategori" => $_POST['kategori'],
            "umkm" => $_POST['umkm'],
            "gambar" => $_FILES['foto'],
        );
        add_product($data);
    }
    if (isset($_POST['edit'])) {
        $data = array(
            "id" => $_POST['id_product'],
            "nama_product" => $_POST['nama_product'],
            "deskripsi" => $_POST['deskripsi'],
            "harga" => $_POST['harga'],
            "stok" => $_POST['stok'],
            "kategori" => $_POST['kategori'],
            "umkm" => $_POST['umkm'],
            "gambar" => $_FILES['foto'],
        );
        edit_product($data);
    }
    if (isset($_GET['hapus'])) {
        $data = array(
            "id" => $_GET['hapus'],
        );
        dell_product($data);
    }
    ?>
</body>

<script>
    $(document).on("click", "#modal", function() {

        var id_product = $(this).data('id_product');
        var nama = $(this).data('nama');
        var deskripsi = $(this).data('deskripsi');
        var harga = $(this).data('harga');
        var stok = $(this).data('stok');
        var kategori = $(this).data('kategori');
        var umkm = $(this).data('umkm');

        var status = $(this).data('status');

        //alert(status);
        if (status == "add") {
            $("#foto1").attr("required", "required");
            $(".modal-footer #proses").attr("name", "add");
            $(".modal-footer #pros").text("Tambahkan");
        } else if (status == "edit") {
            $(".modal-footer #proses").attr("name", "edit");
            $(".modal-footer #pros").text("Simpan Perubahan");
            $("#foto1").removeAttr("required");
        }

        $(".modal-body #id_product").val(id_product);
        $(".modal-body #nama_product").val(nama);
        $(".modal-body #deskripsi").val(deskripsi);
        $(".modal-body #harga").val(harga);
        $(".modal-body #stok").val(stok);
        $(".modal-body #kategori").val(kategori);
        $(".modal-body #umkm").val(umkm);
        //alert(nama);
    });
</script>

</html>