<!DOCTYPE html>
<html lang="en">

<?php
include "../koneksi.php";
include "control.php";
include "auth.php";
?>

<head>
    <title>Admin</title>
</head>
<?php
include 'template/head.php';
?>

<body>
    <script>
        $(document).ready(function() {
            $('#dt').DataTable();
        });
    </script>

    <div class="container-fluid">
        <div class="row flex-nowrap">
            <?php
            include 'template/sidebar.php';
            ?>
            <div class="col py-3">
                <div class="container">
                    <h3>Data Kategori</h3>
                    <br>
                    <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#add">
                        <i class="fa fa-plus"></i>&nbsp;&nbsp;Tambah Data
                    </button>
                    <p></p>
                    <div class="row">
                        <div class="col-md-8">
                            <div class="table-responsive">
                                <table class="table table-hover cell-border" id="dt">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Kategori</th>
                                            <th>#</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    $query = "SELECT * FROM tb_kategori";
                                    $sql = mysqli_query($conn, $query);
                                    $no = 1;
                                    ?>
                                    <tbody>
                                        <?php
                                        while ($result = mysqli_fetch_assoc($sql)) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <center><?php echo $no++; ?>.</center>
                                                </td>
                                                <td><?php echo $result['nama_kategori']; ?></td>
                                                <td>
                                                    <a onclick="return confirm('Apakah Anda Yakin Hapus Data ?');" href="kategori.php?hapus=<?php echo $result['id_kategori']; ?>" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="add" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="" method="POST">
                    <div class="modal-body">
                        <div class="mb-3 mt-3">
                            <input required type="text" name="kat" class="form-control" id="kategori" placeholder="Kategori">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="submit" class="btn btn-primary">
                            <i class="fa fa-save"></i>&nbsp;&nbsp; Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
    if (isset($_POST['submit'])) {
        $data = array(
            "nama_kategori" => $_POST['kat'],
        );
        add_kategori($data);
    }
    if (isset($_GET['hapus'])) {
        $data = array(
            "id" => $_GET['hapus'],
        );
        dell_kategori($data);
    }
    ?>
</body>

</html>