<!DOCTYPE html>
<html>

<?php
include "koneksi.php";
include "c_client.php";

function rupiah($angka)
{

  $hasil_rupiah = "Rp. " . number_format($angka, 2, ',', '.');
  return $hasil_rupiah;
}

?>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>

  <!-- bootstrap -->
  <link rel="stylesheet" href="umkm/css/bootstrap.min.css">
  <script src="umkm/js/bootstrap.bundle.min.js"></script>

  <!-- font awesome -->
  <link rel="stylesheet" href="umkm/fontawesome/css/font-awesome.min.css">

  <title>My Website</title>
</head>

<body>

  <nav class="navbar navbar-expand-lg navbar-warning bg-warning mt-2">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <h3 class="d-inline"><i class="fa fa-shopping-cart mx-2 text-success" aria-hidden="true"></i></h3>
          <a class="navbar-brand text-dark font-weight-bold" href="index.php">Desi Furniture</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>
        <div class="col-md-5">
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item mx-1">
                <a class="nav-link active text-dark" aria-current="page" href="#">Beranda</a>
              </li>
              <li class="nav-item mx-1">
                <a class="nav-link active text-dark" aria-current="page" href="#">Produk</a>
              </li>
              <li class="nav-item mx-1">
                <a class="nav-link active text-dark" aria-current="page" href="#">Tentang Kami</a>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-4">
          <form class="d-flex">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" style="width: 250px;">
            <button class="btn btn-outline-success" type="submit">Search</button>
            <i class="fa fa-shopping-cart mx-2 mt-2" aria-hidden="true"></i>
            <i class="fa fa-envelope mx-2 mt-2" aria-hidden="true"></i>
            <i class="fa fa-bell mx-2 mt-2" aria-hidden="true"></i>
          </form>
        </div>
      </div>
    </div>
  </nav>
  <div class="mt-2">
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-indicators">
        <?php
        $query = "SELECT * FROM tb_slider ORDER BY id_slider DESC";
        $sql = mysqli_query($conn, $query);
        $no = 0;

        while ($result = mysqli_fetch_assoc($sql)) {
        ?>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo $no; ?>" class="<?php if ($no == 0) {
                                                                                                                            echo 'active';
                                                                                                                          } ?>" aria-current="true" aria-label="Slide 1"></button>
        <?php
          $no++;
        }
        ?>
      </div>

      <div class="carousel-inner">

        <?php
        $query = "SELECT * FROM tb_slider ORDER BY id_slider DESC";
        $sql = mysqli_query($conn, $query);
        $no = 0;

        while ($result = mysqli_fetch_assoc($sql)) {
        ?>
          <div class="<?php if ($no == 0) {
                        echo 'carousel-item active';
                      } else {
                        echo 'carousel-item';
                      } ?>">
            <img src="slider/<?php echo $result['foto_slider']; ?>" class="d-block w-100" alt="...">
          </div>
        <?php
          $no++;
        }
        ?>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </div>
  <div class="container">
    <div class="row mt-3">
      <div class="col-md-3 bg-light">
        <ul class="list-group list-group-flush">
          <li class="list-group-item bg-warning">
            <i class="fa fa-list mx-2" aria-hidden="true"></i>
            KATEGORI PRODUK
          </li>
          <?php

          $query = "SELECT * FROM tb_kategori";
          $sql_kategori = mysqli_query($conn, $query);
          while ($result = mysqli_fetch_assoc($sql_kategori)) {
          ?>
            <li class="list-group-item"><i class="fa fa-angle-right mx-3" aria-hidden="true"></i>
              <a href="index.php?kategori=<?php echo $result['id_kategori']; ?>" class="text-decoration-none text-dark"><?php echo $result['nama_kategori']; ?></a>
            </li>
          <?php
          }
          ?>
        </ul>
      </div>
      <div class="col-md-9">
        <h5 class="text-center font-weight-bold mt-3">PRODUK POPULER</h5>
        <div class="row mt-3 mb-5">
          <?php
          if (isset($_GET['kategori'])) {
            $id = $_GET['kategori'];
            $query2 = "SELECT * FROM tb_product WHERE id_kategori='$id' ORDER BY id_product DESC;";
          } else {
            $query2 = "SELECT * FROM tb_product ORDER BY id_product DESC;";
          }

          $sql_product = mysqli_query($conn, $query2);
          while ($result = mysqli_fetch_assoc($sql_product)) {
          ?>
            <div class="col-md-3 col-sm-6 col-6 mb-4">
              <div class="card mb-1" style="width: 12rem;">
                <img src="admin/img/<?= $result['gambar_product']; ?>" class="card-img-top" height="170px">
                <div class="card-body">
                  <h5 class="card-title"><?= $result['nama_product']; ?></h5>
                  <?php
                  $pendek = substr($result['detil_product'], 0, 30);
                  ?>
                  <p class="card-text"><?= $pendek; ?> . . .</p>
                  <div class="row mt-2">
                    <div class="col-md-4 ">
                      <a id="nm" href="#" data-bs-toggle="modal" data-coba="welcome" data-nama="<?= $result['nama_product']; ?>" data-bs-target="#detil" class="btn btn-primary btn-sm">Detail</a>
                    </div>
                    <div class="col-md-8 text-end">
                      <a href="#" class="btn btn-danger btn-sm"><?= $result['harga_product']; ?></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php
          }
          ?>
        </div>
      </div>
    </div>
  </div>

  <footer class="bg-dark text-white p-2">
    <div class="container">
      <div class="row mt-4 mx-4">
        <div class="col-md-4 ">
          <h5>Tentang Kami</h5>
          <ul>
            <li>Tentang Kami</li>
            <li>Syarat dan Ketentuan</li>
          </ul>
        </div>
        <div class="col-md-4 ">
          <h5>Layanan Pelanggan</h5>
          <ul>
            <li>Cara Pembayaran</li>
            <li>Masukan dan Saran</li>
          </ul>
        </div>
        <div class="col-md-4 ">
          <h5>Kontak Kami</h5>
          <ul>
            <li>0812-3456-7890</li>
            <li>Senin-Sabtu</li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  <div class="copyright text-center text-white font-weight-bold bg-warning p-2">
    <p>Development by Desi Rahmawati Copyright <i class="fa fa-copyright" aria-hidden="true"></i> 2021</p>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="detil" tabindex="-1" aria-labelledby="modalTitle" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalTitle">Detail Product</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="card mb-3" style="max-width: 540px;">
            <div class="row g-0">
              <div class="col-md-4">
                <img src="umkm/img/h.jpg" class="img-fluid rounded-start mt-3">
              </div>
              <div class="col-md-8">
                <div class="card-body">
                  <span class="card-text">Jumlah Stok : 20 Biji</span>
                  <span class="card-text">Kategori : Kuliner</span>
                  <span class="card-text"><small class="text-muted">Produksi : Wahana Cipta</small></span>
                  <p class="card-text">Dumbleg merupakan jajanan tradisional khas Nganjuk. Makanan ini terbuat dari tepung beras atau ketan.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-danger">Beli Sekarang</button>
        </div>
      </div>
    </div>
  </div>
</body>
<script>
  $(document).on("click", "#nm", function() {
    let nama = $(this).data('nama');

    $('#modalTitle').text(`Detail Product : ${nama}`);
  });
</script>

</html>